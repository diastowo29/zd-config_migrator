for (var i=0; i<5; i++){
	if (ticket[i] == condition) {
		if (ticket[i] == a) {

		}
		if (ticket[i] == b) {

		}
		if (ticket[i] == c) {

		}	
	}
}